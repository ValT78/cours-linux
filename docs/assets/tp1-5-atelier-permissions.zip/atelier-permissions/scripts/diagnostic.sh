#!/usr/bin/env bash
echo "Diagnostic de la station : OK"
echo "Utilisateur : $(id -un)"
echo "Groupe principal : $(id -gn)"
