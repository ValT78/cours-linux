// Source fictive
int main(void)
{
    return 0;
}
