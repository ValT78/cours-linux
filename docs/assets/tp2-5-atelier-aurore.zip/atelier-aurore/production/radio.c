// Source fictive
void envoyer(void)
{
    // simulation
}

// fin
