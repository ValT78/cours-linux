// Interface fictive
void envoyer(void);
