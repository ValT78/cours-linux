#!/usr/bin/env bash
echo "Diagnostic du relais Aurore"
echo "Journaux de communication :"
find bruts -maxdepth 1 -name "*.log" | wc -l
echo "Lignes critiques :"
grep -h "CRITIQUE" bruts/*.log | wc -l
