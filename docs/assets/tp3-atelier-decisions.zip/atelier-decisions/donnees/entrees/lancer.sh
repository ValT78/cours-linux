#!/usr/bin/env bash
echo 'Temoin executable du laboratoire.'
